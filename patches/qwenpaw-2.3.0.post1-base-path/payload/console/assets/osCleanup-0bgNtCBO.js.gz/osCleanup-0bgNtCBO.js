import{K as G,aG as Q,j as ee,ax as te,cm as oe,bB as ne,dH as re,dI as ae,d0 as ie,c8 as de,dJ as le,a7 as w,dx as $,cc as Y,dK as se,dL as pe,dM as ce,dy as xe,dN as ge}from"./index-vA07rXH8.js";import{r as U}from"./react-vendor-Bso2UVDV.js";import{M as ue}from"./message-square-DQ7CX03z.js";import{F as fe}from"./files-p0POq0D1.js";import{C as be}from"./clock-Cj2eYvWj.js";import{H as he}from"./heart-pulse-Bi8Pev37.js";import{I as me}from"./inbox-CPYBpyg7.js";import{F as we}from"./folder-open-DlHkcCC6.js";import{N as ve}from"./network-DxyVHHj2.js";import{B as ye}from"./blocks--4Eh20Jb.js";/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $e=[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]],ke=G("chart-column",$e);/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ie=[["path",{d:"M15 21v-5a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5",key:"slp6dd"}],["path",{d:"M17.774 10.31a1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.451 0 1.12 1.12 0 0 0-1.548 0 2.5 2.5 0 0 1-3.452 0 1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.77-3.248l2.889-4.184A2 2 0 0 1 7 2h10a2 2 0 0 1 1.653.873l2.895 4.192a2.5 2.5 0 0 1-3.774 3.244",key:"o0xfot"}],["path",{d:"M4 10.95V19a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8.05",key:"wn3emo"}]],Se=G("store",Ie),l="var(--app-accent)",O=56,u=28,h=78,v=14,S=18,Be=9,c="140ms",x="220ms",f="cubic-bezier(0.22, 1, 0.36, 1)",ze={textStrong:"#f1f5f9",text:"#e2e8f0",textSecondary:"#cbd5e1",textMuted:"#94a3b8",textFaint:"#64748b",hoverText:"#fff",winBg:"rgba(24, 24, 27, 0.9)",panelBg:"rgba(28, 28, 30, 0.94)",barBg:"rgba(30, 30, 32, 0.62)",barBgStrong:"rgba(24, 24, 27, 0.8)",cardBg:"rgba(63, 63, 70, 0.32)",floatBg:"rgba(54, 54, 58, 0.58)",floatBgHover:"rgba(72, 72, 78, 0.78)",toastBg:"rgba(38, 38, 42, 0.9)",winCardBg:"rgba(39, 39, 42, 0.72)",overlayBg:"rgba(9, 9, 11, 0.62)",dimBg:"rgba(9, 9, 11, 0.52)",inputBg:"rgba(82, 82, 91, 0.32)",tooltipBg:"rgba(28, 28, 30, 0.94)",sideBg:"rgba(9, 9, 11, 0.22)",hoverBg:"rgba(255, 255, 255, 0.08)",hoverBgStrong:"rgba(255, 255, 255, 0.1)",subtleBg:"rgba(255, 255, 255, 0.06)",faintBg:"rgba(255, 255, 255, 0.03)",contentBg:"rgba(255, 255, 255, 0.02)",border:"rgba(148, 163, 184, 0.14)",borderStrong:"rgba(148, 163, 184, 0.28)",borderSolid:"rgba(148, 163, 184, 0.6)",chipBg:"rgba(148, 163, 184, 0.14)",dockBorder:"rgba(255, 255, 255, 0.12)",dockDivider:"rgba(255, 255, 255, 0.16)",badgeRing:"rgba(30, 41, 59, 0.9)",shadowWindow:"0 36px 90px rgba(0, 0, 0, 0.46), 0 12px 30px rgba(0, 0, 0, 0.32), inset 0 1px 0 rgba(255, 255, 255, 0.08)",shadowPanel:"0 28px 70px rgba(0, 0, 0, 0.42)",shadowFloat:"0 18px 44px rgba(0, 0, 0, 0.34)",shadowToast:"0 18px 46px rgba(0, 0, 0, 0.34)"},Me={textStrong:"#0f172a",text:"#1e293b",textSecondary:"#475569",textMuted:"#64748b",textFaint:"#94a3b8",hoverText:"#0f172a",winBg:"rgba(246, 246, 248, 0.92)",panelBg:"rgba(250, 250, 252, 0.94)",barBg:"rgba(246, 246, 248, 0.68)",barBgStrong:"rgba(246, 246, 248, 0.84)",cardBg:"rgba(255, 255, 255, 0.72)",floatBg:"rgba(255, 255, 255, 0.6)",floatBgHover:"rgba(255, 255, 255, 0.85)",toastBg:"rgba(255, 255, 255, 0.92)",winCardBg:"rgba(255, 255, 255, 0.78)",overlayBg:"rgba(241, 245, 249, 0.72)",dimBg:"rgba(241, 245, 249, 0.55)",inputBg:"rgba(15, 23, 42, 0.05)",tooltipBg:"rgba(255, 255, 255, 0.96)",sideBg:"rgba(15, 23, 42, 0.04)",hoverBg:"rgba(15, 23, 42, 0.05)",hoverBgStrong:"rgba(15, 23, 42, 0.07)",subtleBg:"rgba(15, 23, 42, 0.04)",faintBg:"rgba(15, 23, 42, 0.03)",contentBg:"rgba(15, 23, 42, 0.02)",border:"rgba(15, 23, 42, 0.1)",borderStrong:"rgba(15, 23, 42, 0.2)",borderSolid:"rgba(71, 85, 105, 0.55)",chipBg:"rgba(15, 23, 42, 0.07)",dockBorder:"rgba(15, 23, 42, 0.08)",dockDivider:"rgba(15, 23, 42, 0.12)",badgeRing:"#ffffff",shadowWindow:"0 34px 84px rgba(15, 23, 42, 0.16), 0 10px 28px rgba(15, 23, 42, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.85)",shadowPanel:"0 26px 64px rgba(15, 23, 42, 0.14)",shadowFloat:"0 16px 42px rgba(15, 23, 42, 0.14)",shadowToast:"0 18px 44px rgba(15, 23, 42, 0.13)"},Ae={p:ze},Te={p:Me},Ce=ee(({css:e},{p:t})=>({desktop:e`
    position: fixed;
    inset: 0;
    overflow: hidden;
    user-select: none;
    color: #f4f4f5;
    background: linear-gradient(135deg, #0b1120 0%, #14162e 50%, #1e1b4b 100%);
    font-family:
      "Inter",
      -apple-system,
      BlinkMacSystemFont,
      "Segoe UI",
      sans-serif;
    isolation: isolate;
    overscroll-behavior: none;
    touch-action: manipulation;
    @media (prefers-reduced-motion: reduce) {
      &,
      & * {
        scroll-behavior: auto !important;
        animation-duration: 1ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 1ms !important;
      }
    }
    @media (max-width: 768px) {
      min-height: 100dvh;
    }
  `,iconsGrid:e`
    position: absolute;
    inset: ${u+8}px auto 0 0;
    padding: 20px;
    display: grid;
    grid-auto-flow: column;
    grid-template-rows: repeat(auto-fill, 96px);
    gap: 8px;
    z-index: 0;
    align-content: start;
    @media (max-width: 768px) {
      inset: ${u+8}px 0 ${h+10}px;
      grid-auto-flow: row;
      grid-template-rows: none;
      grid-template-columns: repeat(auto-fill, minmax(84px, 1fr));
      align-content: start;
      overflow-y: auto;
      padding: 16px 12px;
    }
  `,desktopIcon:e`
    width: 84px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 7px;
    padding: 9px 6px 8px;
    border-radius: 13px;
    outline: none;
    cursor: pointer;
    transition:
      background ${c} ease,
      box-shadow ${c} ease;
    &:hover {
      background: rgba(255, 255, 255, 0.1);
    }
    &:hover > div {
      transform: translateY(-2px) scale(1.035);
      box-shadow:
        0 14px 28px rgba(0, 0, 0, 0.5),
        inset 0 1px 0 rgba(255, 255, 255, 0.4),
        inset 0 -2px 6px rgba(0, 0, 0, 0.28);
    }
    span {
      padding: 2px 6px;
      border-radius: 5px;
      font-size: 12px;
      line-height: 16px;
      text-align: center;
      color: #fafafa;
      background: rgba(9, 9, 11, 0.26);
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.72);
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    &:focus-visible {
      box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.92);
    }
  `,desktopIconSelected:e`
    background: rgba(255, 255, 255, 0.16);
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.16);
    span {
      background: rgba(0, 102, 255, 0.82);
      color: #fff;
    }
  `,iconTile:e`
    width: 52px;
    height: 52px;
    border-radius: 13px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    box-shadow:
      0 8px 20px rgba(0, 0, 0, 0.45),
      inset 0 1px 0 rgba(255, 255, 255, 0.35),
      inset 0 -2px 6px rgba(0, 0, 0, 0.25);
    transition:
      transform ${c} ${f},
      box-shadow ${c} ease;
  `,windowsLayer:e`
    position: absolute;
    inset: 0;
    z-index: 10;
    pointer-events: none;
  `,window:e`
    position: absolute;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    border-radius: ${v}px;
    pointer-events: auto;
    outline: none;
    background: ${t.winBg};
    backdrop-filter: saturate(1.18) blur(22px);
    -webkit-backdrop-filter: saturate(1.18) blur(22px);
    border: 1px solid ${t.border};
    box-shadow: ${t.shadowWindow};
    transition:
      border-color ${x} ease,
      box-shadow ${x} ease,
      opacity ${x} ease;
    &:focus-visible {
      box-shadow:
        ${t.shadowWindow},
        0 0 0 2px color-mix(in srgb, var(--app-accent) 74%, transparent);
    }
  `,windowActive:e`
    border-color: rgba(255, 255, 255, 0.24);
    box-shadow:
      ${t.shadowWindow},
      0 0 0 1px var(--app-accent-soft);
  `,header:e`
    height: 40px;
    flex: 0 0 40px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 10px 0 12px;
    background: ${t.barBg};
    border-bottom: 1px solid ${t.border};
    cursor: grab;
    &:active {
      cursor: grabbing;
    }
  `,headerTitle:e`
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    font-weight: 500;
    color: ${t.text};
  `,headerBtns:e`
    display: flex;
    align-items: center;
    gap: 4px;
  `,winBtn:e`
    width: 26px;
    height: 26px;
    border: none;
    background: transparent;
    color: ${t.textMuted};
    border-radius: 7px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.12s ease;
    &:hover {
      background: ${t.hoverBgStrong};
      color: ${t.hoverText};
    }
  `,winBtnClose:e`
    &:hover {
      background: #ef4444;
      color: #fff;
    }
  `,content:e`
    flex: 1;
    overflow: auto;
    position: relative;
    background: ${t.contentBg};
  `,resizeHandle:e`
    position: absolute;
    right: 0;
    bottom: 0;
    width: 16px;
    height: 16px;
    cursor: nwse-resize;
    z-index: 5;
    &::after {
      content: "";
      position: absolute;
      right: 3px;
      bottom: 3px;
      width: 7px;
      height: 7px;
      border-right: 2px solid ${t.borderSolid};
      border-bottom: 2px solid ${t.borderSolid};
    }
  `,resizeArea:e`
    position: absolute;
    z-index: 5;
  `,loading:e`
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  `,taskbar:e`
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: ${O}px;
    z-index: 50;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 12px;
    background: ${t.barBgStrong};
    backdrop-filter: blur(14px);
    -webkit-backdrop-filter: blur(14px);
    border-top: 1px solid ${t.border};
  `,startBtn:e`
    width: 40px;
    height: 40px;
    border: none;
    background: transparent;
    color: ${l};
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: background 0.12s ease;
    &:hover {
      background: ${t.hoverBgStrong};
    }
  `,taskbarApps:e`
    flex: 1;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 0 12px;
    overflow-x: auto;
  `,taskItem:e`
    height: 40px;
    padding: 0 14px;
    border: none;
    border-radius: 8px;
    background: transparent;
    color: ${t.textSecondary};
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    font-size: 13px;
    max-width: 180px;
    transition: all 0.12s ease;
    &:hover {
      background: ${t.hoverBg};
      color: ${t.hoverText};
    }
    span {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  `,taskItemActive:e`
    background: ${t.hoverBgStrong};
    color: ${t.hoverText};
    border-bottom: 2px solid ${l};
  `,tray:e`
    display: flex;
    align-items: center;
    gap: 14px;
    color: ${t.textSecondary};
    font-size: 12px;
  `,clock:e`
    text-align: right;
    line-height: 1.2;
    .date {
      font-size: 10px;
      color: ${t.textMuted};
    }
  `,launcher:e`
    position: absolute;
    inset: 0;
    z-index: 60;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: max(64px, 8vh) clamp(16px, 5vw, 72px) ${h+24}px;
    background: ${t.dimBg};
    backdrop-filter: saturate(1.15) blur(28px);
    -webkit-backdrop-filter: saturate(1.15) blur(28px);
    animation: launcherIn ${x} ${f};
    @keyframes launcherIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
    @media (max-width: 768px) {
      padding: 54px 14px ${h+18}px;
      align-items: flex-start;
    }
  `,launcherSurface:e`
    width: min(920px, 100%);
    max-height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
  `,launcherSearch:e`
    display: flex;
    align-items: center;
    gap: 10px;
    width: min(420px, 100%);
    min-height: 44px;
    padding: 0 15px;
    margin-bottom: clamp(24px, 5vh, 48px);
    border-radius: 13px;
    color: ${t.textMuted};
    background: ${t.floatBg};
    border: 1px solid ${t.borderStrong};
    box-shadow: 0 8px 28px rgba(0, 0, 0, 0.14);
    input {
      flex: 1;
      min-width: 0;
      background: transparent;
      border: none;
      outline: none;
      color: ${t.text};
      font-size: 15px;
      &::placeholder {
        color: ${t.textMuted};
      }
    }
    &:focus-within {
      border-color: rgba(255, 255, 255, 0.36);
      box-shadow:
        0 8px 28px rgba(0, 0, 0, 0.14),
        0 0 0 3px var(--app-accent-ring);
    }
  `,launcherGrid:e`
    width: 100%;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(108px, 1fr));
    gap: clamp(16px, 3vw, 30px) clamp(12px, 2vw, 24px);
    overflow-y: auto;
    padding: 4px 8px 24px;
    align-content: start;
    @media (max-width: 768px) {
      grid-template-columns: repeat(auto-fit, minmax(88px, 1fr));
      gap: 16px 8px;
    }
  `,launcherItem:e`
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    min-height: 108px;
    padding: 10px 8px;
    border-radius: 15px;
    outline: none;
    cursor: pointer;
    transition:
      background ${c} ease,
      transform ${c} ${f};
    &:hover {
      background: ${t.subtleBg};
      transform: translateY(-2px);
    }
    span {
      max-width: 120px;
      font-size: 13px;
      line-height: 17px;
      color: ${t.text};
      text-align: center;
      text-shadow: 0 1px 5px rgba(0, 0, 0, 0.28);
    }
    &:focus-visible {
      box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.72);
    }
  `,launcherIcon:e`
    width: 64px;
    height: 64px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    box-shadow:
      0 12px 24px rgba(0, 0, 0, 0.28),
      inset 0 1px 0 rgba(255, 255, 255, 0.34);
  `,launcherEmpty:e`
    grid-column: 1 / -1;
    padding: 48px 16px;
    color: ${t.textSecondary};
    font-size: 14px;
    text-align: center;
  `,emptyHint:e`
    position: absolute;
    inset: 0 0 ${O}px 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 18px;
    color: ${l};
    pointer-events: none;
    opacity: 0.055;
    z-index: 0;
    img {
      width: 88px;
      height: 88px;
      border-radius: 50%;
      object-fit: contain;
      filter: drop-shadow(0 8px 28px rgba(0, 0, 0, 0.4));
    }
  `,emptyBrandName:e`
    font-family:
      "Inter",
      -apple-system,
      BlinkMacSystemFont,
      sans-serif;
    font-size: 40px;
    font-weight: 700;
    letter-spacing: 0.14em;
    color: #e2e8f0;
    text-shadow: 0 2px 24px rgba(0, 0, 0, 0.4);
  `,storeRoot:e`
    display: flex;
    flex-direction: column;
    height: 100%;
    color: ${t.text};
  `,storeHead:e`
    padding: 20px 24px 12px;
    h2 {
      margin: 0;
      font-size: 20px;
      font-weight: 600;
    }
    p {
      margin: 4px 0 0;
      font-size: 13px;
      color: ${t.textMuted};
    }
  `,storeToolbar:e`
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 24px 12px;
    border-bottom: 1px solid ${t.border};
  `,storeBody:e`
    flex: 1;
    overflow-y: auto;
    padding: 8px 0 20px;
  `,storeGrid:e`
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
    gap: 14px;
    padding: 8px 24px 4px;
    align-content: start;
  `,storeCard:e`
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 16px;
    border-radius: 14px;
    background: ${t.cardBg};
    border: 1px solid ${t.border};
    transition: border-color 0.15s ease;
    &:hover {
      border-color: var(--app-accent-border);
    }
  `,storeCardTop:e`
    display: flex;
    align-items: center;
    gap: 12px;
    .meta {
      min-width: 0;
    }
    .name {
      font-size: 14px;
      font-weight: 600;
    }
    .status {
      font-size: 11px;
      margin-top: 2px;
    }
  `,storeTile:e`
    width: 44px;
    height: 44px;
    flex: 0 0 44px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
  `,storeBtn:e`
    height: 32px;
    border: 1px solid ${t.borderStrong};
    background: transparent;
    color: ${t.text};
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    cursor: pointer;
    font-size: 13px;
    transition: all 0.12s ease;
    &:hover {
      background: ${t.hoverBg};
    }
  `,storeBtnInstall:e`
    border-color: ${l};
    color: ${l};
    &:hover {
      background: var(--app-accent-soft);
    }
  `,storeSectionTitle:e`
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 16px 24px 2px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    color: ${t.textMuted};
  `,storeEmpty:e`
    padding: 14px 24px;
    color: ${t.textFaint};
    font-size: 13px;
  `,pluginBadge:e`
    display: inline-flex;
    align-items: center;
    padding: 1px 8px;
    border-radius: 999px;
    font-size: 11px;
    background: ${t.chipBg};
    color: ${t.textSecondary};
  `,storeToolbarRow:e`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 12px 24px 4px;
    flex-wrap: wrap;
  `,storeChips:e`
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
  `,storeChip:e`
    padding: 4px 12px;
    border-radius: 999px;
    font-size: 12px;
    cursor: pointer;
    color: ${t.textSecondary};
    background: ${t.chipBg};
    border: 1px solid transparent;
    transition: all 0.12s ease;
    &:hover {
      background: ${t.hoverBg};
    }
  `,storeChipActive:e`
    background: var(--app-accent-soft);
    border-color: ${l};
    color: ${t.hoverText};
  `,storeCardDesc:e`
    font-size: 12px;
    color: ${t.textMuted};
    margin-top: 2px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    min-height: 2.4em;
  `,storeCardMeta:e`
    font-size: 11px;
    color: ${t.textFaint};
    margin-top: 4px;
  `,storeActions:e`
    display: flex;
    gap: 8px;
    align-items: center;
  `,storePager:e`
    display: flex;
    justify-content: center;
    padding: 14px 0 4px;
  `,mcOverlay:e`
    position: absolute;
    inset: 0;
    z-index: 80;
    display: flex;
    flex-direction: column;
    padding: clamp(20px, 4vw, 48px);
    gap: 20px;
    background: ${t.overlayBg};
    backdrop-filter: saturate(1.1) blur(26px);
    -webkit-backdrop-filter: saturate(1.1) blur(26px);
    animation: mcFade ${x} ease-out;
    @keyframes mcFade {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
    @media (max-width: 768px) {
      padding: 48px 14px ${h+18}px;
      gap: 14px;
    }
  `,mcSpaces:e`
    display: flex;
    align-items: center;
    gap: 14px;
    overflow-x: auto;
    padding: 4px 2px 12px;
    justify-content: center;
    flex-wrap: wrap;
  `,mcSpaceCard:e`
    width: 176px;
    height: 104px;
    border-radius: ${v}px;
    background: ${t.floatBg};
    border: 2px solid transparent;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8px;
    cursor: pointer;
    outline: none;
    transition:
      background ${c} ease,
      border-color ${c} ease,
      transform ${c} ${f};
    color: ${t.text};
    &:hover {
      background: ${t.floatBgHover};
      transform: translateY(-2px);
    }
    &:focus-visible {
      box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.72);
    }
    .avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      color: #fff;
    }
    .name {
      font-size: 13px;
      font-weight: 500;
      max-width: 150px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .count {
      font-size: 11px;
      color: ${t.textMuted};
    }
    @media (max-width: 768px) {
      width: 142px;
      height: 94px;
    }
  `,mcSpaceActive:e`
    border-color: ${l};
    background: var(--app-accent-soft);
  `,mcSpaceAdd:e`
    width: 56px;
    height: 104px;
    border-radius: ${v}px;
    border: 2px dashed ${t.borderStrong};
    background: transparent;
    color: ${t.textMuted};
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    outline: none;
    transition:
      border-color ${c} ease,
      transform ${c} ${f},
      box-shadow ${c} ease;
    &:hover {
      border-color: ${l};
      color: ${l};
    }
  `,mcWindows:e`
    flex: 1;
    overflow-y: auto;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: 16px;
    align-content: start;
    padding-top: 12px;
    border-top: 1px solid ${t.border};
  `,mcWindowCard:e`
    height: 130px;
    border-radius: 12px;
    background: ${t.winCardBg};
    border: 1px solid ${t.border};
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 10px;
    cursor: pointer;
    transition: all 0.15s ease;
    color: ${t.text};
    &:hover {
      border-color: ${l};
      transform: translateY(-2px);
    }
    &:focus-visible {
      box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.72);
    }
    .title {
      font-size: 13px;
      font-weight: 500;
    }
  `,mcHint:e`
    text-align: center;
    color: ${t.textFaint};
    font-size: 13px;
    padding: 40px 0;
  `,headerMac:e`
    --os-window-control-size: 40px;
    --os-window-controls-width: calc(var(--os-window-control-size) * 3);
    height: 42px;
    flex: 0 0 42px;
    display: grid;
    grid-template-columns:
      var(--os-window-controls-width) minmax(0, 1fr)
      var(--os-window-controls-width);
    align-items: center;
    padding: 0 13px;
    background: ${t.barBg};
    border-bottom: 1px solid ${t.border};
    cursor: grab;
    transition:
      background ${x} ease,
      color ${x} ease;
    &:active {
      cursor: grabbing;
    }
    &[data-active="false"] {
      opacity: 0.86;
    }
    @media (max-width: 600px), (any-pointer: coarse) {
      --os-window-control-size: var(--app-hit-touch);
      height: 52px;
      flex-basis: 52px;
      padding: 0 4px;
    }
  `,lights:e`
    display: flex;
    align-items: center;
    width: var(--os-window-controls-width);
    height: var(--os-window-control-size);
  `,light:e`
    position: relative;
    width: var(--os-window-control-size);
    height: var(--os-window-control-size);
    flex: 0 0 var(--os-window-control-size);
    border-radius: 8px;
    border: none;
    padding: 0;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    color: rgba(0, 0, 0, 0.55);
    background: transparent;
    outline: none;
    &::before {
      content: "";
      position: absolute;
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: var(--traffic-light-color);
      box-shadow: inset 0 0 0 0.5px rgba(0, 0, 0, 0.18);
    }
    svg {
      position: relative;
      z-index: 1;
      opacity: 0;
      transition: opacity ${c} ease;
    }
    &:hover svg {
      opacity: 1;
    }
    &:focus-visible {
      box-shadow: 0 0 0 2px ${l};
    }
    &:disabled {
      cursor: default;
      opacity: 0.55;
    }
  `,lightClose:e`
    --traffic-light-color: #ff5f57;
  `,lightMin:e`
    --traffic-light-color: #febc2e;
  `,lightMax:e`
    --traffic-light-color: #28c840;
  `,macTitle:e`
    flex: 1;
    text-align: center;
    min-width: 0;
    font-size: 12.5px;
    font-weight: 600;
    color: ${t.text};
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  `,menubar:e`
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: ${u}px;
    z-index: 55;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 10px 0 12px;
    background: ${t.barBg};
    backdrop-filter: saturate(1.2) blur(20px);
    -webkit-backdrop-filter: saturate(1.2) blur(20px);
    border-bottom: 1px solid ${t.border};
    font-size: 12px;
    color: ${t.text};
  `,menubarLeft:e`
    display: flex;
    align-items: center;
    min-width: 0;
    gap: 4px;
  `,menubarBrand:e`
    display: flex;
    align-items: center;
    width: 24px;
    height: 24px;
    padding: 2px;
    border: 0;
    border-radius: 6px;
    background: transparent;
    cursor: pointer;
    outline: none;
    img {
      width: 20px;
      height: 20px;
      display: block;
      border-radius: 50%;
    }
    &:hover {
      background: ${t.hoverBg};
    }
    &:focus-visible {
      box-shadow: inset 0 0 0 2px ${l};
    }
  `,menubarName:e`
    min-height: 24px;
    max-width: 180px;
    display: inline-flex;
    align-items: center;
    padding: 0 8px;
    border-radius: 6px;
    font-weight: 700;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    cursor: pointer;
    outline: none;
    &:hover {
      background: ${t.hoverBg};
    }
    &:focus-visible {
      box-shadow: 0 0 0 2px ${l};
    }
  `,menubarItem:e`
    max-width: 180px;
    min-height: 24px;
    display: inline-flex;
    align-items: center;
    padding: 0 8px;
    border-radius: 6px;
    color: ${t.textSecondary};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,menubarRight:e`
    display: flex;
    align-items: center;
    gap: 3px;
    color: ${t.textSecondary};
    @media (max-width: 768px) {
      > svg {
        display: none;
      }
    }
  `,menubarBtn:e`
    display: flex;
    align-items: center;
    background: none;
    border: none;
    color: ${t.textSecondary};
    cursor: pointer;
    min-width: 28px;
    height: 28px;
    justify-content: center;
    padding: 0 6px;
    border-radius: 6px;
    outline: none;
    &:hover {
      background: ${t.hoverBg};
      color: ${t.hoverText};
    }
    &:focus-visible {
      box-shadow: inset 0 0 0 2px ${l};
      color: ${t.hoverText};
    }
  `,dock:e`
    position: absolute;
    left: 50%;
    bottom: 10px;
    transform: translateX(-50%);
    z-index: 50;
    display: flex;
    align-items: flex-end;
    gap: 6px;
    max-width: calc(100vw - 20px);
    padding: 7px 10px 9px;
    border-radius: ${S}px;
    background: ${t.floatBg};
    backdrop-filter: saturate(1.24) blur(24px);
    -webkit-backdrop-filter: saturate(1.24) blur(24px);
    border: 1px solid ${t.dockBorder};
    box-shadow: ${t.shadowFloat};
    overflow-x: auto;
    overflow-y: visible;
    scrollbar-width: none;
    &::-webkit-scrollbar {
      display: none;
    }
    transition:
      transform ${x} ${f},
      opacity ${x} ease;
    @media (max-width: 768px) {
      gap: 4px;
      bottom: max(8px, env(safe-area-inset-bottom));
      padding: 6px 8px 8px;
    }
  `,dockHidden:e`
    transform: translateX(-50%) translateY(140%);
    opacity: 0;
    pointer-events: none;
  `,dockDropActive:e`
    border-color: ${l};
    box-shadow:
      0 0 0 3px var(--app-accent-ring),
      ${t.shadowFloat};
  `,dockItem:e`
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 0 0 auto;
    min-width: 48px;
    min-height: 52px;
    justify-content: flex-end;
    border-radius: 13px;
    outline: none;
    cursor: pointer;
    transition: transform ${c} ${f};
    transform-origin: bottom center;
    &:hover {
      transform: scale(1.18) translateY(-5px);
    }
    &:focus-visible {
      box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.78);
    }
    @media (max-width: 768px) {
      min-width: 44px;
      min-height: 48px;
      &:hover {
        transform: none;
      }
    }
  `,dockItemDragging:e`
    opacity: 0.62;
    transform: scale(1.12) translateY(-8px);
  `,dockIcon:e`
    width: 48px;
    height: 48px;
    border-radius: 13px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    box-shadow:
      0 7px 16px rgba(0, 0, 0, 0.28),
      inset 0 1px 0 rgba(255, 255, 255, 0.28);
    @media (max-width: 768px) {
      width: 44px;
      height: 44px;
      border-radius: 12px;
    }
  `,dockDot:e`
    position: absolute;
    bottom: -5px;
    left: 50%;
    transform: translateX(-50%);
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: ${t.textStrong};
  `,dockTooltip:e`
    position: absolute;
    bottom: 66px;
    left: 50%;
    transform: translateX(-50%);
    padding: 5px 9px;
    border-radius: 7px;
    background: ${t.tooltipBg};
    border: 1px solid ${t.borderStrong};
    color: ${t.text};
    font-size: 12px;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    box-shadow: ${t.shadowFloat};
    transition: opacity ${c} ease;
  `,dockDivider:e`
    width: 1px;
    height: 42px;
    margin: 0 4px;
    background: ${t.dockDivider};
  `,dockBadge:e`
    position: absolute;
    top: -2px;
    right: -2px;
    min-width: 18px;
    height: 18px;
    padding: 0 4px;
    border-radius: 9px;
    background: #ef4444;
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid ${t.badgeRing};
  `,dockDropMarker:e`
    position: absolute;
    left: -5px;
    bottom: 5px;
    width: 3px;
    height: 40px;
    border-radius: 2px;
    background: ${l};
    box-shadow: 0 0 12px ${l};
  `,notificationMenuButton:e`
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    min-width: 28px;
    height: 28px;
    padding: 0 6px;
    border: 0;
    border-radius: 6px;
    background: transparent;
    color: ${t.textSecondary};
    cursor: pointer;
    outline: none;
    &:hover {
      background: ${t.hoverBg};
      color: ${t.hoverText};
    }
    &:focus-visible {
      box-shadow: inset 0 0 0 2px ${l};
      color: ${t.hoverText};
    }
  `,notificationMenuCount:e`
    font-size: 11px;
    line-height: 1;
    font-weight: 600;
    color: currentColor;
    font-variant-numeric: tabular-nums;
  `,toastStack:e`
    position: absolute;
    top: ${u+12}px;
    right: 14px;
    z-index: 70;
    display: flex;
    flex-direction: column;
    gap: 10px;
    width: 340px;
    max-width: calc(100vw - 28px);
    pointer-events: none;
  `,toast:e`
    pointer-events: auto;
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 12px;
    border-radius: ${S}px;
    cursor: pointer;
    background: ${t.toastBg};
    backdrop-filter: blur(18px);
    -webkit-backdrop-filter: blur(18px);
    border: 1px solid ${t.border};
    box-shadow: ${t.shadowToast};
    transition: transform ${c} ${f};
    &:hover {
      transform: scale(1.01);
    }
  `,toastEnter:e`
    @keyframes osToastIn {
      from {
        opacity: 0;
        transform: translateX(24px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }
    animation: osToastIn 0.24s cubic-bezier(0.2, 0.8, 0.2, 1);
  `,toastIcon:e`
    flex: 0 0 auto;
    width: 30px;
    height: 30px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: ${t.subtleBg};
  `,toastBody:e`
    flex: 1;
    min-width: 0;
  `,toastTitle:e`
    font-size: 13px;
    font-weight: 600;
    color: ${t.textStrong};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,toastText:e`
    font-size: 12px;
    color: ${t.textSecondary};
    margin-top: 2px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  `,toastMeta:e`
    font-size: 10px;
    color: ${t.textMuted};
    margin-top: 4px;
  `,toastClose:e`
    flex: 0 0 auto;
    width: 22px;
    height: 22px;
    border: none;
    background: transparent;
    color: ${t.textMuted};
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    &:hover {
      background: ${t.hoverBgStrong};
      color: ${t.hoverText};
    }
  `,notifyActions:e`
    display: flex;
    gap: 8px;
    margin-top: 8px;
  `,notifyApproveBtn:e`
    flex: 1;
    height: 28px;
    border: none;
    border-radius: 8px;
    background: ${l};
    color: #fff;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    &:hover {
      filter: brightness(1.05);
    }
    &:disabled {
      opacity: 0.5;
      cursor: default;
    }
  `,notifyDenyBtn:e`
    flex: 1;
    height: 28px;
    border: 1px solid ${t.borderStrong};
    border-radius: 8px;
    background: transparent;
    color: ${t.text};
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    &:hover {
      background: ${t.hoverBg};
    }
    &:disabled {
      opacity: 0.5;
      cursor: default;
    }
  `,ncPanel:e`
    position: absolute;
    top: ${u+8}px;
    right: 10px;
    bottom: 10px;
    width: 340px;
    max-width: calc(100vw - 20px);
    z-index: 65;
    display: flex;
    flex-direction: column;
    border-radius: ${S}px;
    background: ${t.panelBg};
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid ${t.border};
    box-shadow: ${t.shadowPanel};
    overflow: hidden;
    @media (max-width: 768px) {
      top: ${u+6}px;
      right: 6px;
      bottom: max(8px, env(safe-area-inset-bottom));
      width: calc(100vw - 12px);
      max-width: none;
    }
  `,ncHeader:e`
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 14px;
    border-bottom: 1px solid ${t.border};
  `,ncTitle:e`
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    font-weight: 600;
    color: ${t.textStrong};
  `,ncIconBtn:e`
    width: 36px;
    height: 36px;
    border: none;
    background: transparent;
    color: ${t.textMuted};
    border-radius: ${Be}px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    outline: none;
    &:hover {
      background: ${t.hoverBgStrong};
      color: ${t.hoverText};
    }
    &:focus-visible {
      box-shadow: inset 0 0 0 2px ${l};
    }
  `,ncList:e`
    flex: 1;
    overflow-y: auto;
    padding: 8px;
    display: flex;
    flex-direction: column;
    gap: 8px;
  `,ncEmpty:e`
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 10px;
    color: ${t.textFaint};
    font-size: 13px;
    padding: 40px 0;
  `,ncItem:e`
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 10px;
    border-radius: 12px;
    cursor: pointer;
    outline: none;
    background: ${t.faintBg};
    transition: background 0.12s ease;
    &:hover {
      background: ${t.hoverBg};
    }
    &:focus-visible {
      box-shadow: inset 0 0 0 2px ${l};
    }
  `,ncItemIcon:e`
    flex: 0 0 auto;
    width: 26px;
    height: 26px;
    border-radius: 7px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: ${t.subtleBg};
  `,ncItemBody:e`
    flex: 1;
    min-width: 0;
  `,ncItemTitle:e`
    font-size: 13px;
    font-weight: 600;
    color: ${t.text};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,ncItemText:e`
    font-size: 12px;
    color: ${t.textMuted};
    margin-top: 2px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  `,ncItemTime:e`
    flex: 0 0 auto;
    font-size: 10px;
    color: ${t.textFaint};
  `,settingsRoot:e`
    display: flex;
    height: 100%;
    min-width: 0;
    @media (max-width: 600px) {
      flex-direction: column;
    }
  `,settingsSidebar:e`
    flex: 0 0 220px;
    width: 220px;
    overflow-y: auto;
    padding: 10px;
    border-right: 1px solid ${t.border};
    background: ${t.sideBg};
    @media (max-width: 600px) {
      width: 100%;
      flex: 0 0 auto;
      display: flex;
      gap: 4px;
      padding: 6px;
      overflow-x: auto;
      overflow-y: hidden;
      border-right: 0;
      border-bottom: 1px solid ${t.border};
      scrollbar-width: none;
      &::-webkit-scrollbar {
        display: none;
      }
    }
  `,settingsNavItem:e`
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 9px 12px;
    border-radius: 8px;
    cursor: pointer;
    color: ${t.textSecondary};
    font-size: 13px;
    margin-bottom: 2px;
    border: 0;
    background: transparent;
    font-family: inherit;
    text-align: left;
    transition: background 0.12s ease;
    &:hover {
      background: ${t.subtleBg};
    }
    &:focus-visible {
      box-shadow: inset 0 0 0 2px ${l};
      outline: none;
    }
    @media (max-width: 600px) {
      min-width: 44px;
      min-height: 44px;
      flex: 0 0 auto;
      margin-bottom: 0;
      white-space: nowrap;
    }
  `,settingsNavActive:e`
    background: var(--app-accent-soft);
    color: ${t.hoverText};
  `,settingsPane:e`
    flex: 1;
    min-width: 0;
    min-height: 0;
    overflow: auto;
    position: relative;
    @media (max-width: 600px) {
      .qwenpaw-btn {
        min-height: 44px;
      }
      .qwenpaw-btn-icon-only {
        min-width: 44px;
      }
      .qwenpaw-select-selector {
        min-height: 44px !important;
      }
    }
  `,boot:e`
    position: fixed;
    inset: 0;
    z-index: 200;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 26px;
    background: radial-gradient(
      120% 120% at 50% 40%,
      #14162e 0%,
      #0b1120 60%,
      #05070f 100%
    );
    color: #e2e8f0;
    animation: bootFadeIn 0.4s ease-out;
    @keyframes bootFadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
  `,bootExit:e`
    animation: bootFadeOut 0.4s ease-in forwards;
    @keyframes bootFadeOut {
      from {
        opacity: 1;
      }
      to {
        opacity: 0;
      }
    }
  `,bootBrand:e`
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 14px;
    color: ${l};
    animation: bootPulse 2s ease-in-out infinite;
    @keyframes bootPulse {
      0%,
      100% {
        opacity: 0.85;
        transform: scale(1);
      }
      50% {
        opacity: 1;
        transform: scale(1.04);
      }
    }
  `,bootName:e`
    font-family:
      "Inter",
      -apple-system,
      BlinkMacSystemFont,
      sans-serif;
    font-size: 26px;
    font-weight: 700;
    letter-spacing: 0.06em;
    color: #f1f5f9;
  `,bootBar:e`
    width: 220px;
    height: 4px;
    border-radius: 999px;
    overflow: hidden;
    background: rgba(148, 163, 184, 0.18);
  `,bootBarFill:e`
    height: 100%;
    border-radius: 999px;
    background: linear-gradient(90deg, ${l}, var(--app-accent-hover));
    transition: width 0.12s linear;
  `,bootHint:e`
    font-size: 12px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: #64748b;
  `,desktopMenuAnchor:e`
    position: fixed;
    z-index: 90;
    width: 1px;
    height: 1px;
    pointer-events: none;
  `,desktopContextMenu:e`
    .ant-dropdown-menu {
      min-width: 190px;
      padding: 6px;
      border: 1px solid ${t.border};
      border-radius: 12px;
      background: ${t.panelBg};
      box-shadow: ${t.shadowPanel};
      backdrop-filter: blur(18px);
      -webkit-backdrop-filter: blur(18px);
    }
    .ant-dropdown-menu-item,
    .ant-dropdown-menu-submenu-title {
      min-height: 36px;
      border-radius: 7px;
    }
  `,wpOverlay:e`
    position: absolute;
    inset: 0;
    z-index: 95;
    display: flex;
    align-items: center;
    justify-content: center;
    background: ${t.dimBg};
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    animation: bootFadeIn 0.16s ease-out;
  `,wpPanel:e`
    width: min(560px, 92vw);
    max-height: 76vh;
    display: flex;
    flex-direction: column;
    border-radius: 16px;
    background: ${t.panelBg};
    border: 1px solid ${t.border};
    box-shadow: ${t.shadowPanel};
    overflow: hidden;
  `,wpHead:e`
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 16px;
    font-size: 14px;
    font-weight: 600;
    color: ${t.textStrong};
    border-bottom: 1px solid ${t.border};
  `,wpClose:e`
    width: 26px;
    height: 26px;
    border: none;
    background: transparent;
    color: ${t.textMuted};
    border-radius: 7px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    &:hover {
      background: ${t.hoverBgStrong};
      color: ${t.hoverText};
    }
  `,wpGrid:e`
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
    padding: 16px;
    overflow-y: auto;
  `,wpItem:e`
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 4px;
    border-radius: 13px;
    cursor: pointer;
    outline: none;
    span {
      font-size: 12px;
      color: ${t.textSecondary};
      text-align: center;
    }
    &:focus-visible {
      box-shadow: 0 0 0 2px ${l};
    }
  `,wpItemActive:e`
    span {
      color: ${t.hoverText};
      font-weight: 600;
    }
  `,wpSwatch:e`
    height: 78px;
    border-radius: 12px;
    border: 2px solid transparent;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.35);
    transition: border-color 0.12s ease;
  `,menubarHidden:e`
    transform: translateY(-100%);
    opacity: 0;
    pointer-events: none;
    transition:
      transform 0.22s ease,
      opacity 0.22s ease;
  `,menubarShown:e`
    transform: translateY(0);
    opacity: 1;
    transition:
      transform 0.22s ease,
      opacity 0.22s ease;
  `,spacesPanel:e`
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    z-index: 60;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 14px;
    padding: 12px 18px;
    background: ${t.barBgStrong};
    backdrop-filter: saturate(1.2) blur(22px);
    -webkit-backdrop-filter: saturate(1.2) blur(22px);
    border-bottom: 1px solid ${t.border};
    transform: translateY(0);
    transition:
      transform ${x} ${f},
      opacity ${x} ease;
  `,spacesPanelHidden:e`
    transform: translateY(-100%);
    opacity: 0;
    pointer-events: none;
  `,spaceChip:e`
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 12px 6px 6px;
    border-radius: 999px;
    cursor: pointer;
    border: 1px solid transparent;
    outline: none;
    transition:
      background ${c} ease,
      border-color ${c} ease;
    &:hover {
      background: ${t.hoverBg};
    }
    &:focus-visible {
      box-shadow: 0 0 0 2px ${l};
    }
    .avatar {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-weight: 700;
      font-size: 14px;
    }
    .name {
      font-size: 13px;
      color: ${t.text};
      white-space: nowrap;
    }
  `,spaceChipActive:e`
    border-color: ${l};
    background: var(--app-accent-soft);
  `,snapPreview:e`
    position: absolute;
    z-index: 9;
    border-radius: ${v}px;
    background: var(--app-accent-ring);
    border: 2px solid ${l};
    pointer-events: none;
    transition:
      left 0.12s ease,
      top 0.12s ease,
      width 0.12s ease,
      height 0.12s ease;
  `,iconsLayer:e`
    position: absolute;
    inset: 0;
    z-index: 0;
    pointer-events: none;
  `,iconAbsolute:e`
    position: absolute;
    pointer-events: auto;
    touch-action: none;
  `,windowMinimizing:e`
    transform: scale(0.2) translateY(60vh);
    opacity: 0;
    transition:
      transform ${x} ease-in,
      opacity ${x} ease-in;
    transform-origin: bottom center;
  `,reducedMotion:e`
    @media (prefers-reduced-motion: reduce) {
      animation: none !important;
      transition-duration: 1ms !important;
    }
  `}));function bt(){const{isDark:e}=Q();return Ce(e?Ae:Te)}function He(e,t,o){const n=u,r=o-u;if(e==="maximize")return{x:0,y:n,w:t,h:r};const a=Math.floor(t/2);return e==="left"?{x:0,y:n,w:a,h:r}:{x:t-a,y:n,w:a,h:r}}const k=[{routeId:"core.chat",labelKey:"nav.chat",fallback:"Chat",Icon:ue,accent:"#3b82f6",defaultW:880,defaultH:640},{routeId:"core.files",labelKey:"nav.files",fallback:"Files",Icon:fe,accent:"#f36b21",defaultW:1180,defaultH:720,minW:760,minH:480},{routeId:"core.skills",labelKey:"nav.skills",fallback:"Skills",Icon:te,accent:"#8b5cf6",defaultW:780,defaultH:560},{routeId:"core.cron-jobs",labelKey:"nav.cronJobs",fallback:"Cron Jobs",Icon:be,accent:"#f97316",defaultW:720,defaultH:520},{routeId:"core.mcp",labelKey:"nav.mcp",fallback:"MCP",Icon:oe,accent:"#06b6d4",defaultW:760,defaultH:540},{routeId:"core.tools",labelKey:"nav.tools",fallback:"Tools",Icon:ne,accent:"#10b981",defaultW:720,defaultH:500},{routeId:"core.heartbeat",labelKey:"nav.heartbeat",fallback:"Heartbeat",Icon:he,accent:"#ef4444",defaultW:560,defaultH:440},{routeId:"core.channels",labelKey:"nav.channels",fallback:"Channels",Icon:re,accent:"#22c55e",defaultW:680,defaultH:500},{routeId:"core.inbox",labelKey:"nav.inbox",fallback:"Inbox",Icon:me,accent:"#eab308",defaultW:640,defaultH:500},{routeId:"core.sessions",labelKey:"nav.sessions",fallback:"Sessions",Icon:ae,accent:"#0ea5e9",defaultW:820,defaultH:600,minW:780,minH:480},{routeId:"core.workspace",labelKey:"nav.workspace",fallback:"Workspace",Icon:we,accent:"#f59e0b",defaultW:900,defaultH:640},{routeId:"core.acp",labelKey:"nav.acp",fallback:"ACP",Icon:ve,accent:"#14b8a6",defaultW:780,defaultH:560},{routeId:"core.agent-config",labelKey:"nav.agentConfig",fallback:"Agent Config",Icon:ie,accent:"#7c3aed",defaultW:1020,defaultH:640,minW:900,minH:520},{routeId:"core.agent-stats",labelKey:"nav.agentStats",fallback:"Agent Stats",Icon:ke,accent:"#ec4899",defaultW:820,defaultH:600,minW:900,minH:520}];function Pe(e){return e===A.routeId?A:e===T.routeId?T:e===C.routeId?C:k.find(t=>t.routeId===e)}const A={routeId:"os.store",labelKey:"os.appStore",fallback:"App Store",Icon:Se,accent:"var(--app-accent)",defaultW:860,defaultH:600},T={routeId:"core.marketplace",labelKey:"nav.marketplace",fallback:"Extension",Icon:ye,accent:"#0ea5e9",defaultW:1180,defaultH:720,minW:760,minH:480},C={routeId:"os.settings",labelKey:"os.systemSettings",fallback:"System Settings",Icon:de,accent:"#6b7280",defaultW:1200,defaultH:720,minW:960,minH:560},q="/apps/",j=["#6366f1","#ec4899","#14b8a6","#f59e0b","#8b5cf6","#0ea5e9","#ef4444","#22c55e"];function We(e){let t=0;for(let o=0;o<e.length;o+=1)t=t*31+e.charCodeAt(o)>>>0;return j[t%j.length]}function Oe(e){return(e.replace(q,"").split("/")[0]||e).split(/[-_]/).filter(Boolean).map(o=>o.charAt(0).toUpperCase()+o.slice(1)).join(" ")}function X(e,t){const o=new Map;for(const r of t)r.route&&typeof r.label=="string"&&o.set(r.route,r.label);const n=new Map;for(const r of e)!r.path.startsWith(q)||r.source==="core"||n.has(r.source)||n.set(r.source,r);return[...n.entries()].map(([r,a])=>{const i=o.get(a.id)??Oe(a.path)??r;return{routeId:a.id,labelKey:i,fallback:i,Icon:le,accent:We(r),defaultW:960,defaultH:680,source:r}})}const R=k.map(e=>e.routeId),je=w()($(e=>({installed:R,install:t=>e(o=>o.installed.includes(t)?o:{installed:[...o.installed,t]}),uninstall:t=>e(o=>({installed:o.installed.filter(n=>n!==t)})),installAll:()=>e({installed:k.map(t=>t.routeId)})}),{name:"qwenpaw-os-installed",version:1,migrate:e=>{const t=e??{},o=t.installed??[],n=Array.from(new Set([...o,...R]));return{...t,installed:n}}}));function Re(){const e=Y(),t=se();return U.useMemo(()=>X(e,t),[e,t])}let _=null,E=null,F=new Map;function V(){const e=pe.snapshot(),t=ce.snapshot();return(e!==_||t!==E)&&(_=e,E=t,F=new Map(X(e,t).map(o=>[o.routeId,o]))),F}function J(e){return Pe(e)??V().get(e)}function _e(e){return[...V().values()].filter(t=>t.source===e)}function ht(){const e=Y(),t=je(n=>n.installed),o=Re();return U.useMemo(()=>{const n=new Set(e.map(d=>d.id)),r=new Set(t),a=k.filter(d=>n.has(d.routeId)&&r.has(d.routeId)),i=[A,T,...a,...o,C];return{apps:i,appById:new Map(i.map(d=>[d.routeId,d]))}},[e,t,o])}const Ee=80,Fe=360,De=260,Ne=40,Ke=140;function Le(e,t,o){const n=Math.max(u,o-t);return Math.min(Math.max(e,u),n)}function H(e,t,o,n){const r=Math.max(Fe,o-Ne),a=Math.max(De,n-Ke),i=Math.min(Math.max(e.w,t.minW??0),r),d=Math.min(Math.max(e.h,t.minH??0),a),s=Math.min(Math.max(e.x,0),Math.max(0,o-Ee)),p=Le(e.y,d,n);return{x:s,y:p,w:i,h:d}}const D=100,N=28,Ge=250;function Ye(e){let t=null,o=null;const n=()=>{if(t!==null&&clearTimeout(t),t=null,!o)return;const{name:r,value:a}=o;o=null,!(typeof window>"u")&&window.localStorage.setItem(r,a)};return typeof window<"u"&&window.addEventListener("pagehide",n),{getItem:r=>window.localStorage.getItem(r),setItem:(r,a)=>{o={name:r,value:a},t!==null&&clearTimeout(t),t=setTimeout(n,e)},removeItem:r=>{(o==null?void 0:o.name)===r&&(t!==null&&clearTimeout(t),t=null,o=null),window.localStorage.removeItem(r)}}}const Ue=Ye(Ge);function qe(e,t,o){const n=J(e.id),r={minW:n==null?void 0:n.minW,minH:n==null?void 0:n.minH};return{...e,...H(e,r,t,o),prev:e.prev?H(e.prev,r,t,o):void 0}}function y(e,t,o){const n={};for(const[r,a]of Object.entries(e??{}))n[r]=qe(a,t,o);return n}const m=w()($((e,t)=>({windows:{},order:[],activeId:null,zCounter:D,launcherOpen:!1,spaceId:"default",saved:{},missionControlOpen:!1,open:(o,n)=>{const r=t();if(r.windows[o]){e(g=>({windows:{...g.windows,[o]:{...g.windows[o],minimized:!1}}})),t().focus(o);return}const a=r.order.length,i=J(o),d=H({x:80+a*N,y:60+a*N,w:(n==null?void 0:n.w)??(i==null?void 0:i.defaultW)??820,h:(n==null?void 0:n.h)??(i==null?void 0:i.defaultH)??580},{minW:(n==null?void 0:n.minW)??(i==null?void 0:i.minW),minH:(n==null?void 0:n.minH)??(i==null?void 0:i.minH)},window.innerWidth,window.innerHeight),s=r.zCounter+1,p={id:o,...d,z:s,minimized:!1,maximized:!1};e(g=>({windows:{...g.windows,[o]:p},order:[...g.order,o],activeId:o,zCounter:s,launcherOpen:!1}))},close:o=>e(n=>{const r={...n.windows};delete r[o];const a=n.order.filter(i=>i!==o);return{windows:r,order:a,activeId:n.activeId===o?a[a.length-1]??null:n.activeId}}),focus:o=>e(n=>{const r=n.windows[o];if(!r)return{};const a=n.zCounter+1;return{windows:{...n.windows,[o]:{...r,z:a,minimized:!1}},zCounter:a,activeId:o}}),minimize:o=>e(n=>{const r=n.windows[o];return r?{windows:{...n.windows,[o]:{...r,minimized:!0}},activeId:n.activeId===o?null:n.activeId}:{}}),toggleFromTaskbar:o=>{const n=t(),r=n.windows[o];r&&(r.minimized?t().focus(o):n.activeId===o?t().minimize(o):t().focus(o))},toggleMaximize:o=>e(n=>{const r=n.windows[o];if(!r)return{};if(r.maximized){const a=r.prev??{x:80,y:60,w:820,h:580};return{windows:{...n.windows,[o]:{...r,...a,maximized:!1,prev:void 0}}}}return{windows:{...n.windows,[o]:{...r,maximized:!0,prev:{x:r.x,y:r.y,w:r.w,h:r.h}}}}}),move:(o,n,r)=>e(a=>{const i=a.windows[o];return i?{windows:{...a.windows,[o]:{...i,x:n,y:r}}}:{}}),resize:(o,n)=>e(r=>{const a=r.windows[o];return a?{windows:{...r.windows,[o]:{...a,...n}}}:{}}),snap:(o,n)=>e(r=>{const a=r.windows[o];if(!a)return{};const i=a.prev??{x:a.x,y:a.y,w:a.w,h:a.h};if(n==="maximize")return{windows:{...r.windows,[o]:{...a,maximized:!0,prev:i}}};const d=He(n,window.innerWidth,window.innerHeight);return{windows:{...r.windows,[o]:{...a,...d,maximized:!1,prev:i}}}}),setLauncher:o=>e({launcherOpen:o}),switchSpace:o=>e(n=>{if(o===n.spaceId)return{missionControlOpen:!1};const r={...n.saved};n.order.length>0?r[n.spaceId]={windows:n.windows,order:n.order,activeId:n.activeId,zCounter:n.zCounter}:delete r[n.spaceId];const a=r[o]??{windows:{},order:[],activeId:null,zCounter:D};return delete r[o],{saved:r,spaceId:o,windows:a.windows,order:a.order,activeId:a.activeId,zCounter:a.zCounter,launcherOpen:!1,missionControlOpen:!1}}),setMissionControl:o=>e({missionControlOpen:o}),clampToViewport:()=>e(o=>{const n=window.innerWidth,r=window.innerHeight,a={};for(const[i,d]of Object.entries(o.saved))a[i]={...d,windows:y(d.windows,n,r)};return{windows:y(o.windows,n,r),saved:a}}),purgeApps:o=>e(n=>{const r=s=>{const p=new Set([...s.order,...Object.keys(s.windows)].filter(b=>o.has(b)));if(p.size===0)return{space:s,changed:!1};const g={...s.windows};for(const b of p)delete g[b];const I=s.order.filter(b=>!o.has(b)),Z=s.activeId!==null&&!o.has(s.activeId)?s.activeId:I[I.length-1]??null;return{space:{...s,windows:g,order:I,activeId:Z},changed:!0}},a=r({windows:n.windows,order:n.order,activeId:n.activeId,zCounter:n.zCounter}),i={};let d=!1;for(const[s,p]of Object.entries(n.saved)){const g=r(p);i[s]=g.space,d=d||g.changed}return!a.changed&&!d?{}:{windows:a.space.windows,order:a.space.order,activeId:a.space.activeId,saved:d?i:n.saved}}),purgeSpace:o=>e(n=>{const r={};if(o in n.saved){const a={...n.saved};delete a[o],r.saved=a}return o===n.spaceId&&(r.windows={},r.order=[],r.activeId=null),r})}),{name:"qwenpaw-os-windows",version:3,storage:xe(()=>Ue),partialize:e=>({windows:e.windows,order:e.order,activeId:e.activeId,zCounter:e.zCounter,spaceId:e.spaceId,saved:e.saved}),migrate:e=>{const t=e??{},o=window.innerWidth,n=window.innerHeight,r={};for(const[a,i]of Object.entries(t.saved??{}))r[a]={...i,windows:y(i.windows,o,n)};return{...t,windows:y(t.windows,o,n),saved:r}},onRehydrateStorage:()=>e=>{e==null||e.clampToViewport()}})),B=104,Xe=96,Ve=20,K=u+8+20;function L(e,t){const o=Math.max(B,t-K-h),n=Math.max(1,Math.floor(o/B)),r=Math.floor(e/n),a=e%n;return{x:Ve+r*Xe,y:K+a*B}}const Je=w()($(e=>({positions:{},layout:"free",setPosition:(t,o,n)=>e(r=>({positions:{...r.positions,[t]:{x:o,y:n}}})),setLayout:t=>e({layout:t}),arrange:(t,o)=>e(n=>{const r={...n.positions};return t.forEach((a,i)=>{r[a]=L(i,o)}),{positions:r}}),reflowToViewport:(t,o)=>e(n=>{if(n.layout!=="free")return{};const r={...n.positions};let a=!1;return t.forEach((i,d)=>{const s=L(d,o),p=n.positions[i];((p==null?void 0:p.x)!==s.x||(p==null?void 0:p.y)!==s.y)&&(r[i]=s,a=!0)}),a?{positions:r}:{}}),purge:t=>e(o=>{if(![...t].some(r=>r in o.positions))return{};const n={...o.positions};for(const r of t)delete n[r];return{positions:n}}),reset:()=>e({positions:{},layout:"free"})}),{name:"qwenpaw.os.iconPositions"})),z="os.settings",Ze={"core.acp-alias":"core.acp"},Qe=new Set(["core.community","core.agents","core.models","core.skill-pool","core.environments","core.security","core.offload-policy","core.token-usage","core.backups","core.voice-transcription","core.debug"]);function mt(e){return e&&e.replace(/\/\*$/,"").replace(/\/:.*$/,"")||"/"}function P(e){return e.split(/[?#]/,1)[0].replace(/\/+$/,"")||"/"}function et(e,t){const o=P(e),n=P(t),r=o.split("/").filter(Boolean),a=n.split("/").filter(Boolean);let i=0;if(a.length===0)return r.length===0?1e3:-1;for(let d=0;d<a.length;d+=1){const s=a[d];if(s==="*")return i+1;const p=r[d];if(!p)return-1;if(s.startsWith(":"))i+=2;else if(s===p)i+=s.length+4;else return-1}return r.length===a.length?i+1e3:i}function tt(e,t){var n;const o=Ze[e.id];return o||(e.source===void 0||e.source==="core"?e.id:((n=t.find(r=>r.source===e.source&&r.path.startsWith("/apps/")))==null?void 0:n.id)??e.id)}function wt(e,t){if(P(e)==="/")return;let o,n=-1;for(const r of t){const a=et(e,r.path);a>n&&(o=r,n=a)}return o?tt(o,t):void 0}const ot=w(e=>({targets:{},openApp:(t,o)=>{o!==void 0&&e(n=>{var r;return{targets:{...n.targets,[t]:{path:o,nonce:(((r=n.targets[t])==null?void 0:r.nonce)??0)+1}}}}),m.getState().open(t)},navigateTo:(t,o)=>{if(Qe.has(t)){e(n=>{var r;return{targets:{...n.targets,[z]:{path:t,nonce:(((r=n.targets[z])==null?void 0:r.nonce)??0)+1}}}}),m.getState().open(z);return}e(n=>{var r;return{targets:{...n.targets,[t]:{path:o,nonce:(((r=n.targets[t])==null?void 0:r.nonce)??0)+1}}}}),m.getState().open(t)},purge:t=>e(o=>{if(![...t].some(r=>r in o.targets))return o;const n={...o.targets};for(const r of t)delete n[r];return{targets:n}})})),W=["core.chat","core.inbox","os.store"];function M(e){return Array.isArray(e)?[...new Set(e.filter(t=>typeof t=="string"))]:[...W]}const nt=w()($(e=>({pinned:[...W],pin:(t,o)=>e(n=>{if(n.pinned.includes(t))return{};const r=[...n.pinned],a=Math.max(0,Math.min(o??r.length,r.length));return r.splice(a,0,t),{pinned:M(r)}}),unpin:t=>e(o=>({pinned:o.pinned.filter(n=>n!==t)})),move:(t,o)=>e(n=>{if(!n.pinned.includes(t)||t===o)return{};const r=n.pinned.filter(i=>i!==t),a=o?r.indexOf(o):r.length;return r.splice(a<0?r.length:a,0,t),{pinned:M(r)}}),purge:t=>e(o=>({pinned:o.pinned.filter(n=>!t.has(n))})),reset:()=>e({pinned:[...W]})}),{name:"qwenpaw.os.dock",merge:(e,t)=>{const o=e;return{...t,pinned:M(o==null?void 0:o.pinned)}}}));function rt(e){const t=new Set(e);t.size!==0&&(m.getState().purgeApps(t),Je.getState().purge(t),ot.getState().purge(t),nt.getState().purge(t))}function at(e){rt(_e(e).map(t=>t.routeId))}function vt(e){at(e),ge(e)}function yt(e){m.getState().purgeSpace(e)}export{l as A,ke as C,u as M,k as O,Se as S,m as a,He as b,Le as c,ot as d,wt as e,J as f,ht as g,nt as h,je as i,rt as j,z as k,mt as l,A as m,Je as n,L as o,yt as p,C as q,vt as r,bt as u};
